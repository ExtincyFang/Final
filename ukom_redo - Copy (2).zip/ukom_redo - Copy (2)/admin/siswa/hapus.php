<?php
include "../../includes/koneksi.php";
$id = intval($_GET['id']);

mysqli_query($koneksi,"DELETE FROM tb_user WHERE id_user=$id");

header("location:index.php?msg=1");
