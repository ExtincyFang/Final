<?php
session_start();

/* =========================
CEK LOGIN ADMIN
========================= */
if (!isset($_SESSION['role']) || $_SESSION['role'] != "admin") {
    header("location:../../index.php");
    exit;
}

$_SESSION['menu'] = "siswa";

include "../../includes/koneksi.php";
include "../../includes/navbarAdmin.php";
?>

<main class="flex-fill">
<div class="container mt-4">

<h2 class="mb-4">Manajemen Siswa</h2>

<button class="btn btn-primary mb-3"
data-bs-toggle="modal"
data-bs-target="#tambah">
+ Tambah Siswa
</button>

<?php if(isset($_GET['msg'])): ?>
<div id="notif" class="alert alert-success">
✅ Data berhasil diproses
</div>

<script>
setTimeout(()=>{
    document.getElementById('notif').remove();
    window.history.replaceState(null,null,window.location.pathname);
},1000);
</script>
<?php endif; ?>


<!-- =========================
TABEL SISWA
========================= -->
<div class="table-responsive">
<table class="table">

<thead class="table-info">
<tr>
<th>No</th>
<th>Nama</th>
<th>NIS</th>
<th>Email</th>
<th>Kelas</th>
<th>Aksi</th>
</tr>
</thead>

<tbody>

<?php
$no = 1;
$query = mysqli_query($koneksi,"
SELECT u.*, k.nama_kelas
FROM tb_user u
LEFT JOIN tb_kelas k ON u.id_kelas = k.id_kelas
WHERE u.role='user'
ORDER BY u.nama ASC
");

while($d = mysqli_fetch_array($query)){
?>

<tr>
<td><?= $no++; ?></td>
<td><?= htmlspecialchars($d['nama']); ?></td>
<td><?= htmlspecialchars($d['nis']); ?></td>
<td><?= htmlspecialchars($d['email']); ?></td>
<td><?= $d['nama_kelas'] ?? '-'; ?></td>

<td>

<button class="btn btn-warning btn-sm"
data-bs-toggle="modal"
data-bs-target="#ubah<?= $d['id_user']; ?>">
Ubah
</button>

<a href="hapus.php?id=<?= $d['id_user']; ?>"
class="btn btn-danger btn-sm"
onclick="return confirm('Yakin hapus siswa ini?')">
Hapus
</a>

</td>
</tr>


<!-- =========================
MODAL UBAH
========================= -->
<div class="modal fade" id="ubah<?= $d['id_user']; ?>">
<div class="modal-dialog">
<div class="modal-content">

<form action="ubah.php" method="POST">

<div class="modal-header">
<h5 class="modal-title">Ubah Siswa</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>

<div class="modal-body">

<input type="hidden" name="id_user" value="<?= $d['id_user']; ?>">

<input type="text" name="nama" class="form-control mb-2"
value="<?= $d['nama']; ?>" required>

<input type="text" name="nis" class="form-control mb-2"
value="<?= $d['nis']; ?>" required>

<input type="email" name="email" class="form-control mb-2"
value="<?= $d['email']; ?>" required>

<select name="id_kelas" class="form-control mb-2" required>

<?php
$kelas = mysqli_query($koneksi,"SELECT * FROM tb_kelas");
while($k = mysqli_fetch_array($kelas)){
$sel = ($k['id_kelas']==$d['id_kelas'])?'selected':'';
echo "<option value='$k[id_kelas]' $sel>$k[nama_kelas]</option>";
}
?>

</select>

<input type="password"
name="password"
class="form-control"
placeholder="Kosongkan jika tidak ganti password">

</div>

<div class="modal-footer">
<button class="btn btn-warning">Update</button>
</div>

</form>

</div>
</div>
</div>

<?php } ?>

</tbody>
</table>
</div>



<!-- =========================
MODAL TAMBAH
========================= -->
<div class="modal fade" id="tambah">
<div class="modal-dialog">
<div class="modal-content">

<form action="tambah.php" method="POST">

<div class="modal-header">
<h5 class="modal-title">Tambah Siswa</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>

<div class="modal-body">

<input type="text" name="nama" class="form-control mb-2" placeholder="Nama" required>

<input type="text" name="nis" class="form-control mb-2" placeholder="NIS" required>

<input type="email" name="email" class="form-control mb-2" placeholder="Email" required>

<select name="id_kelas" class="form-control mb-2" required>
<option value="">-- Pilih Kelas --</option>

<?php
$kelas = mysqli_query($koneksi,"SELECT * FROM tb_kelas");
while($k = mysqli_fetch_array($kelas)){
echo "<option value='$k[id_kelas]'>$k[nama_kelas]</option>";
}
?>

</select>

<input type="password" name="password" class="form-control" placeholder="Password" required>

</div>

<div class="modal-footer">
<button class="btn btn-primary">Simpan</button>
</div>

</form>

</div>
</div>
</div>

</div>
</main>

<script src="../../bootstrap/js/bootstrap.bundle.min.js"></script>
