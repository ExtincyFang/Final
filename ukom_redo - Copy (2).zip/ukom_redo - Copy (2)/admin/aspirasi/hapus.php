<?php
session_start();
include "../../includes/koneksi.php";

if($_SESSION['role'] != "admin"){
    exit;
}

$id = $_GET['id'];

/* hapus foto dulu */
$data = mysqli_fetch_array(
    mysqli_query($koneksi,"SELECT * FROM tb_aspirasi WHERE id_aspirasi='$id'")
);

if($data['foto']!=""){
    unlink("../../uploads/".$data['foto']);
}

/* hapus db */
mysqli_query($koneksi,"DELETE FROM tb_aspirasi WHERE id_aspirasi='$id'");

header("location:index.php");
exit;
?>
