<?php
session_start();

/* CEK ROLE ADMIN */
if (!isset($_SESSION['role']) || $_SESSION['role'] != "admin") {
    header("location:../../index.php");
    exit;
}

$_SESSION['menu'] = "aspirasi";

include "../../includes/koneksi.php";
include "../../includes/navbarAdmin.php";
?>

<main class="flex-fill">
<div class="container mt-4">

<h3 class="mb-3">Manajemen Aspirasi Siswa</h3>

<div class="table-responsive">
<table class="table table-bordered table-striped">

<thead class="table-info text-center">
<tr>
<th>No</th>
<th>Nama Siswa</th>
<th>Kategori</th>
<th>Lokasi</th>
<th>Aspirasi</th>
<th>Foto</th>
<th>Status</th>
<th>Tanggal</th>
<th width="120">Aksi</th>
</tr>
</thead>

<tbody>

<?php
$no=1;

$query = mysqli_query($koneksi,"
SELECT a.*, u.nama, k.nama_kategori
FROM tb_aspirasi a
JOIN tb_user u ON a.id_user=u.id_user
JOIN tb_kategori k ON a.id_kategori=k.id_kategori
ORDER BY a.created_at DESC
");

$allowedNext = [
    'menunggu' => ['proses', 'ditolak'],
    'proses'   => ['selesai', 'ditolak'],
    'selesai'  => [],
    'ditolak'  => [],
];

while($d = mysqli_fetch_array($query)){
$current = $d['status'];
?>

<tr>
<td class="text-center"><?= $no++ ?></td>
<td><?= htmlspecialchars($d['nama']) ?></td>
<td><?= htmlspecialchars($d['nama_kategori']) ?></td>
<td><?= htmlspecialchars($d['lokasi']) ?></td>
<td width="250"><?= htmlspecialchars($d['isi_aspirasi']) ?></td>

<td class="text-center">
<?php if(!empty($d['foto'])): ?>
    <img 
        src="../../<?= $d['foto'] ?>" 
        alt="Foto Aspirasi" 
        style="width:80px; border-radius:5px; cursor:pointer;"
        data-bs-toggle="modal"
        data-bs-target="#fotoModal"
        onclick="previewFoto('../../<?= $d['foto'] ?>')"
    >
<?php else: ?>
    <span class="text-muted">Tidak ada</span>
<?php endif; ?>
</td>

<td>
<form action="update_status.php" method="POST">
<input type="hidden" name="id" value="<?= $d['id_aspirasi'] ?>">

<select name="status" class="form-select form-select-sm"
        onchange="this.form.submit()"
        <?= empty($allowedNext[$current]) ? 'disabled' : '' ?>>
    <option value="<?= $current ?>" selected>
        <?= ucfirst($current) ?>
    </option>
    <?php foreach ($allowedNext[$current] as $next) { ?>
        <option value="<?= $next ?>"><?= ucfirst($next) ?></option>
    <?php } ?>
</select>
</form>
</td>

<td><?= date('d-m-Y H:i', strtotime($d['created_at'])) ?></td>

<td class="text-center d-flex flex-column gap-1">
<?php if(in_array($d['status'], ['menunggu','proses'])): ?>
    <a href="../../siswa/feedback.php?id=<?= $d['id_aspirasi'] ?>" 
       class="btn btn-success btn-sm d-flex align-items-center justify-content-center gap-1">
       <i class="bi bi-chat-dots"></i> Chat
    </a>
<?php elseif($d['status']=='selesai'): ?>
    <span class="badge bg-success"><i class="bi bi-check-square-fill"></i> Selesai</span>
<?php elseif($d['status']=='ditolak'): ?>
    <span class="badge bg-danger"><i class="bi bi-x-circle-fill"></i> Ditolak</span>
<?php endif; ?>
</td>

</tr>

<?php } ?>

</tbody>
</table>
</div>

</div>
</main>

<div class="modal fade" id="fotoModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Preview Foto</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body text-center">
        <img id="modalImage" src="" class="img-fluid rounded">
      </div>
    </div>
  </div>
</div>

<script>
function previewFoto(src) {
    document.getElementById('modalImage').src = src;
}
</script>

<script src="<?= base_url ?>bootstrap/js/bootstrap.bundle.min.js"></script>
<?php include "../../includes/footer.php"; ?>
