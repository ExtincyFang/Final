<?php
session_start();
include "../../includes/koneksi.php";

// Cek login & role admin
if (!isset($_SESSION['role']) || $_SESSION['role'] != "admin") {
    exit("Akses ditolak");
}

// Validasi POST
if (!isset($_POST['id']) || !isset($_POST['status'])) {
    exit("Data tidak lengkap");
}

$id     = mysqli_real_escape_string($koneksi, $_POST['id']);
$status = mysqli_real_escape_string($koneksi, $_POST['status']);

// Ambil status saat ini dari database
$query = mysqli_query($koneksi, 
    "SELECT status FROM tb_aspirasi WHERE id_aspirasi='$id'"
);

if (!$query || mysqli_num_rows($query) == 0) {
    exit("Aspirasi tidak ditemukan");
}

$data = mysqli_fetch_assoc($query);
$currentStatus = $data['status'];

// Aturan urutan status
$allowedNext = [
    'menunggu' => ['proses', 'ditolak'],   
    'proses'   => ['selesai', 'ditolak'],  
    'selesai'  => [],                       
    'ditolak'  => [],                       
];

// Cegah error kalau status tidak dikenal
if (!isset($allowedNext[$currentStatus])) {
    exit("Status saat ini tidak dikenali");
}

// Cek apakah status baru valid
if (!in_array($status, $allowedNext[$currentStatus])) {
    exit("Status tidak valid. Status saat ini: $currentStatus");
}

// Update status
$update = mysqli_query($koneksi, 
    "UPDATE tb_aspirasi 
     SET status='$status' 
     WHERE id_aspirasi='$id'"
);

if (!$update) {
    exit("Gagal memperbarui status");
}

// Redirect kembali
header("Location: index.php");
exit;
?>
