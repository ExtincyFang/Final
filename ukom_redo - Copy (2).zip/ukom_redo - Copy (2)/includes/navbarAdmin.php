<?php include "baseurl.php"; ?>

<link rel="stylesheet" href="<?= base_url ?>bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="<?= base_url ?>bootstrap-icons/bootstrap-icons.css">

<style>
/* Navbar horizontal info */
.navbar-custom {
    background-color: var(--bs-info); /* Gunakan warna info Bootstrap */
}

.navbar-custom .navbar-brand,
.navbar-custom .nav-link,
.navbar-custom .dropdown-item {
    color: #fff;
    font-weight: 500;
    transition: 0.2s;
}

.navbar-custom .nav-link:hover,
.navbar-custom .dropdown-item:hover {
    color: #e6f7ff; /* Sedikit lebih terang saat hover */
}

.navbar-custom .nav-link.active {
    font-weight: bold;
    text-decoration: underline;
}

/* Konten halaman */
.main-content {
    padding: 20px;
}
</style>

<nav class="navbar navbar-expand-lg navbar-custom">
  <div class="container-fluid">
    <a class="navbar-brand" href="<?= base_url ?>admin">LearnerVoice!</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
      aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon" style="color:#fff;"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link <?= ($_SESSION['menu']=="dashboard")?'active':'' ?>" href="<?= base_url ?>admin">
            <i class="bi bi-speedometer2"></i> Dashboard
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= ($_SESSION['menu']=="kelas")?'active':'' ?>" href="<?= base_url ?>admin/kelas">
            <i class="bi bi-building"></i> Kelas
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= ($_SESSION['menu']=="siswa")?'active':'' ?>" href="<?= base_url ?>admin/siswa">
            <i class="bi bi-people"></i> Siswa
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= ($_SESSION['menu']=="kategori")?'active':'' ?>" href="<?= base_url ?>admin/kategori">
            <i class="bi bi-tags"></i> Kategori
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= ($_SESSION['menu']=="aspirasi")?'active':'' ?>" href="<?= base_url ?>admin/aspirasi">
            <i class="bi bi-chat-dots"></i> Aspirasi
          </a>
        </li>
      </ul>

      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="btn btn-outline-light" href="<?= base_url ?>login/logout.php">
            <i class="bi bi-box-arrow-right"></i> Keluar
          </a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<div class="main-content">
    <!-- Konten halaman admin di sini -->
</div>

<script src="<?= base_url ?>bootstrap/js/bootstrap.bundle.min.js"></script>
