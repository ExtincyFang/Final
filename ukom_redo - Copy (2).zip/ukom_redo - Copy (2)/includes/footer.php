  
    <!-- awal footer  -->
        <div class="row bg-info text-light mt-2">
            <div class="col-12">
                <div class="container md-3">

                    <hr>
                    <div class="row">
                        <div class="col-8   ">
                            <p class="fs-5">&copy;LearnerVoice!  2026</p>
                        </div>
                        <div class="col-4 text-end">
                            <a href="https://www.instagram.com/" class="text-light text-decoration-none" target="blank">
                                <i class="bi bi-instagram fs-5 mx-1"></i>LearnerVoice!
                            </a>
                            <a href="https://web.telegram.org/" class="text-light text-decoration-none" target="blank">
                                <i class="bi bi-facebook fs-5 mx-1"></i>LearnerVoice!
                            </a>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <!-- akir footer  -->
    <script src="<?= base_url."bootstrap/js/bootstrap.bundle.js"; ?>"></script>
    </body>
    </html>




   
