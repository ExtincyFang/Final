<?php
session_start();
include "../includes/koneksi.php";
include "../includes/baseurl.php";
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tentang - LearnerVoice!</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body{
            background: linear-gradient(180deg, #caf0f8, #ade8f4, #90e0ef);
            min-height:100vh;
        }
        .card{
            border-radius:15px;
        }
        footer{
            background:#48cae4;
            color:white;
        }
        .navbar{
            background:#48cae4 !important;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark shadow fixed-top">
    <div class="container-fluid px-4">
        <a href="index.php" class="navbar-brand fw-bold">LearnerVoice!</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
               
                <li class="nav-item"><a href="tentang.php" class="nav-link active">Tentang</a></li>
                <li class="nav-item ms-2">
                    <a href="../login/logout.php" class="btn btn-danger">Keluar</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Content -->
<div class="container mt-5 pt-5 mb-5">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card shadow-lg">
                <div class="card-body p-4">

                    <h3 class="fw-bold text-center mb-3">Tentang LearnerVoice!</h3>
                    <p class="text-center text-muted">Platform Aspirasi & Suara Pelajar Digital</p>

                    <hr>

                    <p style="text-align: justify;">
                        <b>LearnerVoice!</b> adalah sistem informasi aspirasi pelajar yang dirancang untuk membantu siswa 
                        menyampaikan pendapat, laporan, kritik, serta saran secara digital dengan mudah, cepat, dan aman.
                        Platform ini hadir untuk mendukung lingkungan sekolah yang lebih terbuka, komunikatif,
                        serta responsif terhadap kebutuhan dan suara peserta didik.
                    </p>

                    <p style="text-align: justify;">
                        Dengan LearnerVoice!, siswa dapat menyampaikan berbagai aspirasi tanpa hambatan serta 
                        memantau perkembangan laporan yang telah dikirim secara transparan. 
                        Sistem ini juga membantu pihak sekolah dalam mengelola aspirasi siswa secara terstruktur dan efisien.
                    </p>

                    <div class="row mt-4">
                        <div class="col-md-4 text-center mb-3">
                            <i class="bi bi-chat-dots fs-1 text-info"></i>
                            <h6 class="fw-bold mt-2">Sampaikan Pendapat</h6>
                            <p class="small text-muted">Sampaikan aspirasi dengan mudah melalui sistem digital.</p>
                        </div>

                        <div class="col-md-4 text-center mb-3">
                            <i class="bi bi-graph-up fs-1 text-info"></i>
                            <h6 class="fw-bold mt-2">Pantau Perkembangan</h6>
                            <p class="small text-muted">Lihat status dan progres laporan secara transparan.</p>
                        </div>

                        <div class="col-md-4 text-center mb-3">
                            <i class="bi bi-shield-lock fs-1 text-info"></i>
                            <h6 class="fw-bold mt-2">Data Aman</h6>
                            <p class="small text-muted">Semua data tersimpan dengan sistem keamanan yang baik.</p>
                        </div>
                    </div>

                    <div class="alert alert-info mt-4 text-center">
                        <i class="bi bi-lightbulb"></i>
                        LearnerVoice! dikembangkan sebagai bagian dari <b>Proyek UKOM (Uji Kompetensi Keahlian)</b>
                        untuk mendukung transformasi digital di lingkungan pendidikan.
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<!-- Footer -->
<footer class="w-100 text-center py-3 mt-auto">
    <small>© <?php echo date('Y'); ?> LearnerVoice! All Rights Reserved.</small>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
