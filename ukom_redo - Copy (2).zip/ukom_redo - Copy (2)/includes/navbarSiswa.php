 <nav class="navbar navbar-expand-lg navbar-dark bg-info     shadow fixed-top">
  <div class="container">
    
    <!-- Brand -->
    <a href="" class="navbar-brand fw-bold">LearnerVoice!</a>

    <!-- Toggle Button (Hamburger) -->
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarAduin">
      <span class="navbar-toggler-icon"></span>
    </button>

    <!-- Menu -->
    <div class="collapse navbar-collapse" id="navbarAduin">
      <ul class="navbar-nav ms-auto align-items-lg-center gap-2">

        <li class="nav-item">
          <a href="" class="nav-link">Fitur</a>
        </li>

       
        <li class="nav-item">
          <a href="../login/logout.php" class="btn btn-danger">
            Keluar
          </a>
        </li>

      </ul>
    </div>
  </div>
</nav>
