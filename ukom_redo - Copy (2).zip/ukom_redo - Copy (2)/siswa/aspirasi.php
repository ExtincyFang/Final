<?php
session_start();
include "../includes/koneksi.php";

if(!isset($_SESSION['id_user'])){
    header("Location: ../login/login.php");
    exit;
}

$id_user     = $_SESSION['id_user'];
$id_kategori = $_POST['id_kategori'];
$lokasi      = $_POST['lokasi'];
$isi         = $_POST['isi_aspirasi'];

if($id_kategori == "" || $lokasi == "" || $isi == ""){
    echo "<script>
        alert('Semua field wajib diisi!');
        window.history.back();
    </script>";
    exit;
}

/* =====================
   Upload File Foto
===================== */
$foto = NULL; // default null kalau tidak upload

if(isset($_FILES['foto']) && $_FILES['foto']['error'] == 0){

    $namaFile = $_FILES['foto']['name'];
    $tmpName  = $_FILES['foto']['tmp_name'];

    $namaBaru = time() . "_" . $namaFile;
    $folder   = "../uploads/";

    // pastikan folder ada
    if(!is_dir($folder)){
        mkdir($folder, 0777, true);
    }

    if(move_uploaded_file($tmpName, $folder . $namaBaru)){
        $foto = "uploads/" . $namaBaru;
    }
}

/* =====================
   Insert Data
===================== */
$query = mysqli_query($koneksi, "
    INSERT INTO tb_aspirasi
    (id_user, id_kategori, lokasi, isi_aspirasi, foto, status, created_at, updated_at)
    VALUES
    ('$id_user', '$id_kategori', '$lokasi', '$isi', '$foto', 'menunggu', NOW(), NOW())
");

if($query){
    echo "<script>
        alert('Aspirasi berhasil dikirim!');
        window.location.href='index.php';
    </script>";
}else{
    echo "<script>
        alert('Gagal mengirim aspirasi!');
        window.history.back();
    </script>";
}
?>
