<?php
session_start();
$_SESSION['menu'] = "profil";
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'siswa') {
   
}

include "../includes/koneksi.php";
include "../includes/navbarSiswa.php";

$id_user = $_SESSION['id_user'];

// Ambil data user
$q = mysqli_query($koneksi, "SELECT tb_user.*, tb_kelas.nama_kelas, tb_kelas.tahun_ajaran 
FROM tb_user 
LEFT JOIN tb_kelas ON tb_user.id_kelas = tb_kelas.id_kelas 
WHERE tb_user.id_user='$id_user'");
$data = mysqli_fetch_assoc($q);
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Profil Siswa</title>
  <style>
body{
    background: linear-gradient(180deg, #0077b6, #0096c7, #48cae4);
    min-height:100vh;
}

/* layout utama */
.main-content{
    margin-left:240px;
    padding:20px;
    transition:.3s;
}

/* responsive */
@media(max-width:768px){
    .main-content{
        margin-left:0;
        padding:15px;
    }
}
.profile-card{
    max-width:500px;
    margin:auto;
    border-radius:16px;
    box-shadow:0 10px 25px rgba(0,0,0,0.12);
}
.profile-item{
    display:flex;
    justify-content:space-between;
    padding:10px 0;
    border-bottom:1px solid #eee;
    font-size:15px;
}
.profile-item:last-child{
    border-bottom:none;
}
.profile-label{
    font-weight:600;
    color:#555;
}
.profile-value{
    font-weight:500;
    color:#000;
    text-align:right;
}
</style>

</head>
<link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="../bootstrap-icons/bootstrap-icons.css">

<body class="bg-light">
<div class="main-content">
<div class="container mt-5 pt-4">

  <div class="ktp-card ">

 <div class="card profile-card">
  <div class="card-header bg-primary text-white text-center fw-bold">
    Profil Siswa
  </div>

  <div class="card-body">

    <div class="profile-item">
      <div class="profile-label">Nama</div>
      <div class="profile-value"><?php echo htmlspecialchars($data['nama']); ?></div>
    </div>

    <div class="profile-item">
      <div class="profile-label">NIS</div>
      <div class="profile-value"><?php echo htmlspecialchars($data['nis']); ?></div>
    </div>

    <div class="profile-item">
      <div class="profile-label">Email</div>
      <div class="profile-value"><?php echo htmlspecialchars($data['email']); ?></div>
    </div>

    <div class="profile-item">
      <div class="profile-label">Jenis Kelamin</div>
      <div class="profile-value"><?php echo htmlspecialchars($data['jenis_kelamin'] ?? '-'); ?></div>
    </div>

    <div class="profile-item">
      <div class="profile-label">Kelas</div>
      <div class="profile-value"><?php echo htmlspecialchars($data['nama_kelas'] ?? '-'); ?></div>
    </div>

    <div class="profile-item">
      <div class="profile-label">Tahun Ajaran</div>
      <div class="profile-value"><?php echo htmlspecialchars($data['tahun_ajaran'] ?? '-'); ?></div>
    </div>

    <div class="text-center mt-4">
      <a href="profil_edit.php" class="btn btn-outline-primary w-100">
        <i class="bi bi-pencil-square"></i> Ubah Profil
      </a>
    </div>

  </div>
</div>


</div>

</div>
</div>
</body>
</html>
